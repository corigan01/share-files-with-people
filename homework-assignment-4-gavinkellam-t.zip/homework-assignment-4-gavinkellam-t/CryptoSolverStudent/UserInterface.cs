namespace CryptoSolver
{
    /// <summary>
    /// THe GUI
    /// </summary>
    public partial class UserInterface : Form
    {
        /// <summary>
        /// The cipher class
        /// </summary>
        private SubstitutionCipher _cipher = new();
        
        public UserInterface()
        {
            InitializeComponent();

            if (uxOpenFile.ShowDialog() == DialogResult.OK)
            {
                string filename = uxOpenFile.FileName;
                
                if (!_cipher.ReadDictionary(filename))
                {
                    MessageBox.Show("Could Not Open/Read Dictionary!");
                }
            }
        }

        /// <summary>
        /// Encrypt Button Event handler
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event args</param>
        private void EncryptButtonEventHandlerClick(object sender, EventArgs e)
        {
            string boxContent = uxMessage.Text;
            
            int errorInt = _cipher.ContainsInvalid(boxContent) ? 0b01 : 0;
            errorInt |= _cipher.AllWords(boxContent) ? 0 : 0b10;

            if (errorInt != 0)
            {
                string errorString;
                switch (errorInt)
                {
                    case 0b01:
                        errorString = "Message contains invalid characters!";
                        break;
                    case 0b10:
                        errorString = "Message contains non-dictionary words";
                        break;
                    case 0b11:
                        errorString = "Message contains non-dictionary words and invalid characters!";
                        break;
                    default:
                        errorString = "";
                        break;
                }

                MessageBox.Show(errorString, "Could not Encrypt Message!");
                return;
            }

            uxResult.Text = _cipher.Encrypt(boxContent);
        }

        /// <summary>
        /// decrypt button
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event args</param>
        private void DecryptButtonEventHandlerClick(object sender, EventArgs e)
        {
            string boxContent = uxMessage.Text;

            if (_cipher.ContainsInvalid(boxContent))
            {
                MessageBox.Show("Message contains invalid characters!", "Could not Decrypt Message!");
                return;
            }

            string messageReal = _cipher.Decrypt(boxContent, out bool wasSuccess);
            if (!wasSuccess)
            {
                MessageBox.Show("Could not solve decryption!", "Message not decrypted");
                return;
            }

            uxResult.Text = messageReal;
        }
    }
}
