﻿/* TrieWithNoChildren.cs
 * Julie Thornton
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CryptoSolver
{
    /// <summary>
    /// Represents a trie with no children
    /// </summary>
    public class TrieWithNoChildren : ITrie
    {
        /// <summary>
        /// If this Trie represents the end of a word
        /// </summary>
        private bool _isWord;

        /// <summary>
        /// Adds the given string to this trie. This trie may or may not
        /// be changed by this method, but the resulting trie is always
        /// returned.
        /// </summary>
        /// <param name="s">The string to add.</param>
        /// <returns>The resulting trie.</returns>
        public ITrie Add(string s)
        {
            if (s == null)
            {
                throw new ArgumentNullException();
            }
            if (s == "")
            {
                _isWord = true;
                return this;
            }
            
            return new TrieWithOneChild(s, _isWord);
        }

        /// <summary>
        /// Determines whether this trie contains the given string.
        /// </summary>
        /// <param name="s">The string to look for.</param>
        /// <returns>Whether this trie contains s.</returns>
        public bool Contains(string s)
        {
            if (s == null)
            {
                throw new ArgumentNullException();
            }
            if (s == "")
            {
                return _isWord;
            }

            return false;
        }

        /// <summary>
        /// Searches the Trie for a wildcard
        /// </summary>
        /// <param name="s">the string</param>
        /// <returns>if it finds it</returns>
        public bool WildcardSearch(string s)
        {
            if (s == null)
            {
                throw new ArgumentNullException();
            }

            if (s == "")
            {
                return _isWord;
            }

            return false;
        }

    }
}
