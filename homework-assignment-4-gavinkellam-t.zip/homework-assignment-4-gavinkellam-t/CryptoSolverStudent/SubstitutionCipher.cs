﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CryptoSolver
{
    /// <summary>
    /// If suffering was a class
    /// </summary>
    public class SubstitutionCipher
    {
        /// <summary>
        /// Random Number Generator
        /// </summary>
        private Random _generator = new();
        
        /// <summary>
        /// Word List
        /// </summary>
        private ITrie _words = new TrieWithNoChildren();

        /// <summary>
        /// Checks whether all words in key are in the dictionary
        /// </summary>
        /// <param name="key">the word to check</param>
        /// <returns>If the word is found</returns>
        public bool AllWords(string key)
        {
            string[] wordsInKey = key.Split(" ");

            foreach (string word in wordsInKey)
            {
                // Checking invalid is considerably faster then checking the Trie
                // so if we find an invalid char, then we know its not in the word
                // list.
                if (ContainsInvalid(word))
                {
                    return false;
                }

                if (!_words.Contains(word))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Returns whether key contains characters other then lower-case
        /// letters or spaces.
        /// </summary>
        /// <param name="key">the string to check</param>
        /// <returns>if the string is invalid</returns>
        public bool ContainsInvalid(string key)
        {
            foreach (char c in key)
            {
                if (c == ' ')
                {
                    continue;
                }
                
                int normalized = c - ITrie.AlphabetStart;
                if (normalized > ITrie.AlphabetSize || normalized < 0)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Decrypts the message and returns the first possible solution.
        /// Solved is set to whether or not a solution was found. 
        /// </summary>
        /// <param name="message">the message</param>
        /// <param name="solved">if it was solved</param>
        /// <returns>the potential decrypted string</returns>
        public string Decrypt(string message, out bool solved)
        {
            if (ContainsInvalid(message))
            {
                solved = false;
                return "";
            }

            string[] cipher = message.Split(" ");
            StringBuilder[] partial = new StringBuilder[cipher.Length];

            for (int i = 0; i < partial.Length; i++)
            {
                partial[i] = new StringBuilder();
                for (int charCount = 0; charCount < cipher[i].Length; charCount++)
                {
                    partial[i].Append('?');
                }
            }

            bool[] alphaUsed = new bool[ITrie.AlphabetSize];
            solved = DecryptionSearch(cipher, partial, alphaUsed);

            if (!solved)
            {
                return "";
            }

            StringBuilder outputString = new();
            for (int i = 0; i < partial.Length; i++)
            {
                outputString.Append(partial[i]);
                
                // If not the last word
                if (i != partial.Length - 1)
                    outputString.Append(' ');
            }

            return outputString.ToString();
        }

        /// <summary>
        /// performs a recursive search to solve the cryptogram.
        /// </summary>
        /// <param name="cipher">the words of the encrypted message</param>
        /// <param name="partial">the current partial solution to the cipher</param>
        /// <param name="alphaUsed">already used letters</param>
        /// <returns>if solved</returns>
        private bool DecryptionSearch(string[] cipher, StringBuilder[] partial, bool[] alphaUsed)
        {
            // If partial represents a solved puzzle (i.e. it contains no ? characters, and each
            // StringBuilder is a word in the trie), it will return true.
            if (Solved(partial))
            {
                return true;
            }
            
            // Otherwise, if any word in partial does NOT have a possible match in the trie, return false.
            // This is what the method PossibleCompletion() does.
            if (!PossibleCompletion(partial))
            {
                return false;
            }
            
            // extend the recursive search by finding the first location of a ‘?’ in the StringBuilders in the partial array
            int[] nextUnknown = NextPosition(partial);
            for (int i = 0; i < partial.Length; i++)
            {
                if (nextUnknown[i] == -1)
                {
                    continue;
                }
                
                // Get the ciphertext value, v, (in cipher) at that same word and character position.
                char charToReplace = cipher[i][nextUnknown[i]];
                
                // Then for each unused lowercase letter, ‘l’ (consult alphaUsed)
                for (int alphaIndex = 0; alphaIndex < alphaUsed.Length; alphaIndex++)
                {
                    if (alphaUsed[alphaIndex])
                    {
                        continue;
                    }
                
                    alphaUsed[alphaIndex] = true;
                    char nextCharToTry = (char)(alphaIndex + ITrie.AlphabetStart);
                    
                    // use the Substitute method to replace the appropriate locations in partial
                    Substitute(charToReplace, nextCharToTry, cipher, partial);
                    
                    // Recursively call DecryptionSearch with that substitution
                    if (DecryptionSearch(cipher, partial, alphaUsed))
                    {
                        return true;
                    }
                    
                    // and then if necessary, backtrack by undoing the recent substitution. (What does this mean?)
                    //
                    // To backtrack, set the index in alphaUsed to false and call Substitute to replace ‘l’ with ‘?’.
                    alphaUsed[alphaIndex] = false;
                }
                
                Substitute(charToReplace, '?', cipher, partial);
            }
            
            return false;
        }

        /// <summary>
        /// Applies a random substitution cipher to encrypt the message, and returns the resulting ciphertext.
        /// </summary>
        /// <param name="message">the message to encrypt</param>
        /// <returns>the encrypted message</returns>
        public string Encrypt(string message)
        {
            if (ContainsInvalid(message))
            {
                throw new ArgumentException();
            }
            
            StringBuilder sb = new();
            int randomCipher = _generator.Next(ITrie.AlphabetSize);

            foreach (char messageChar in message)
            {
                if (messageChar == ' ')
                {
                    sb.Append(messageChar);
                    continue;
                }
                
                int unNormalChar = (messageChar - ITrie.AlphabetStart) + randomCipher;
                int normalizedChar = unNormalChar % ITrie.AlphabetSize;
                char cipherChar = (char)(normalizedChar + ITrie.AlphabetStart);

                sb.Append(cipherChar);
            }

            return sb.ToString();
        }

        /// <summary>
        /// Returns a size-2 array of the position of the next ? character in plain (position 0: the index of the
        /// first word in plain with a ?, and position 1: the index of the first ? within that word).
        /// If there are no wildcards return null.
        /// </summary>
        /// <param name="plain">the strings to check position</param>
        /// <returns>a size-2 array of positions of the next char</returns>
        private int[] NextPosition(StringBuilder[] plain)
        {
            int[] posNext = new int[plain.Length];

            for (int i = 0; i < posNext.Length; i++)
            {
                posNext[i] = -1;
            }
            
            for (int i = 0; i < plain.Length; i++)
            {
                StringBuilder plainWord = plain[i];

                for (int charPos = 0; charPos < plainWord.Length; charPos++)
                {
                    if (plainWord[charPos] == '?')
                    {
                        posNext[i] = charPos;
                        break;
                    }
                }
            }

            return posNext;
        }

        /// <summary>
        /// Returns whether the words in plain have possible completions in the _words trie.
        /// Each entry in plain will be a partially completed word,
        /// with ? at the positions that have not been assigned.
        /// </summary>
        /// <param name="plain">possible completion words</param>
        /// <returns>Has possible completions</returns>
        private bool PossibleCompletion(StringBuilder[] plain)
        {
            foreach (StringBuilder plainWord in plain)
            {
                if (!_words.WildcardSearch(plainWord.ToString()))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Reads the fileName input file of allowable words and adds them to the _words trie.
        /// This method returns whether the file was successfully read.
        /// </summary>
        /// <param name="fileName">The filename of the file</param>
        /// <returns>if the file was successfully read</returns>
        public bool ReadDictionary(string fileName)
        {
            if (fileName == "")
            {
                return false;
            }

            // Unsure about the behaviour here, seems 50/50 if we should handle this in main. 
            // Realistically *should* be handled in main, but the 'bool' function annotation is confusing. 
            try
            {
                // Looking at C# docs, this is the updated correct way to use `using`. 
                using StreamReader file = File.OpenText(fileName);
                while (!file.EndOfStream)
                {
                    string? fileLine = file.ReadLine();
                    if (fileLine == null)
                    {
                        continue;
                    }

                    _words = _words.Add(fileLine);
                }
            }
            catch
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Returns whether the words in plain are a completed decryption
        /// (with no ? characters and with the _words trie containing all the words)
        /// </summary>
        /// <param name="plain">the message</param>
        /// <returns>If the string is solved or not</returns>
        public bool Solved(StringBuilder[] plain)
        {
            foreach (StringBuilder word in plain)
            {
                string checkingMessage = word.ToString();
                
                if (ContainsInvalid(checkingMessage))
                {
                    return false;
                }

                if (!_words.Contains(checkingMessage))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// For all occurrences of orig in cipher, substitutes the corresponding position with replace in plain
        /// </summary>
        /// <param name="orig">the cipher char</param>
        /// <param name="replace">the char to replace orig with</param>
        /// <param name="cipher">the encrypted words</param>
        /// <param name="plain">the plain text words</param>
        private void Substitute(char orig, char replace, string[] cipher, StringBuilder[] plain)
        {
            if (cipher.Length != plain.Length)
            {
                throw new ArgumentException();
            }
            
            for (int i = 0; i < cipher.Length; i++)
            {
                string cipherWord = cipher[i];

                if (cipherWord.Length != plain[i].Length)
                {
                    throw new ArgumentException();
                }

                for (int charPos = 0; charPos < cipherWord.Length; charPos++)
                {
                    char cipherChar = cipherWord[charPos];

                    if (cipherChar == orig)
                    {
                        plain[i][charPos] = replace;
                    }
                }
            }
        }
    }
}