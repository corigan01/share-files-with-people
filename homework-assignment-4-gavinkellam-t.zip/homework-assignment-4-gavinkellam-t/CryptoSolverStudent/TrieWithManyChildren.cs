﻿/* TrieWithManyChildren.cs
 * Julie Thornton
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CryptoSolver
{
    /// <summary>
    /// Represents a trie with more than one child
    /// </summary>
    public class TrieWithManyChildren : ITrie
    {
        /// <summary>
        /// If this Trie represents the end of a word
        /// </summary>
        private bool _isWord;
        
        /// <summary>
        /// Children of Trie
        /// </summary>
        private ITrie?[] _children = new ITrie?[ITrie.AlphabetSize];
        
        /// <summary>
        /// Constructs a trie containing the given string and having the given child at the given label.
        /// If s contains any characters other than lower-case English letters,
        /// throws an ArgumentException.
        /// If childLabel is not a lower-case English letter, throws an ArgumentException.
        /// </summary>
        /// <param name="s">The string to include.</param>
        /// <param name="hasEmpty">Indicates whether this trie should contain the empty string.</param>
        /// <param name="childLabel">The label of the child.</param>
        /// <param name="child">The child labeled childLabel.</param>
        public TrieWithManyChildren(string s, bool hasEmpty, char childLabel, ITrie child)
        {
            if (s == null || child == null)
            {
                throw new ArgumentNullException();
            }
            if (childLabel < ITrie.AlphabetStart || childLabel >= ITrie.AlphabetStart + ITrie.AlphabetSize)
            {
                throw new ArgumentException();
            }
            _isWord = hasEmpty;
            _children[childLabel - ITrie.AlphabetStart] = child;
            Add(s);
        }

        /// <summary>
        /// Adds the given string to this trie. This trie may or may not
        /// be changed by this method, but the resulting trie is always
        /// returned.
        /// </summary>
        /// <param name="s">The string to add.</param>
        /// <returns>The resulting trie.</returns>
        public ITrie Add(string s)
        {
            if (s == null)
            {
                throw new ArgumentNullException();
            }
            if (s == "")
            {
                _isWord = true;
            }
            else
            {
                int loc = s[0] - ITrie.AlphabetStart;
                if (loc < 0 || loc >= ITrie.AlphabetSize)
                {
                    throw new ArgumentException();
                }
                ITrie? child = _children[loc];
                if (child == null)
                {
                    child = new TrieWithNoChildren();
                }
                _children[loc] = child.Add(s.Substring(1));
            }
            
            return this;
        }

        /// <summary>
        /// Determines whether this trie contains the given string.
        /// </summary>
        /// <param name="s">The string to look for.</param>
        /// <returns>Whether this trie contains s.</returns>
        public bool Contains(string s)
        {
            if (s == null)
            {
                throw new ArgumentNullException();
            }
            if (s == "")
            {
                return _isWord;
            }
            
            int loc = s[0] - ITrie.AlphabetStart;
            if (loc < 0 || loc >= ITrie.AlphabetSize)
            {
                return false;
            }

            ITrie? child = _children[loc];
            if (child == null)
            {
                return false;
            }
            return child.Contains(s.Substring(1));
        }

        /// <summary>
        /// Searches the Trie for a wildcard
        /// </summary>
        /// <param name="s">the string</param>
        /// <returns>if it finds it</returns>
        public bool WildcardSearch(string s)
        {
            if (s == null)
            {
                throw new ArgumentNullException();
            }

            if (s == "")
            {
                return _isWord;
            }

            if (s[0] == '?')
            {
                foreach (ITrie? child in _children)
                {
                    if (child == null)
                    {
                        continue;
                    }
                    
                    if (child.WildcardSearch(s.Substring(1)))
                    {
                        return true;
                    }
                }

                return false;
            }
            
            int normalized = s[0] - ITrie.AlphabetStart;
            if (normalized > ITrie.AlphabetSize || normalized < 0)
            {
                return false;
            }

            ITrie? trieChild = _children[normalized];

            if (trieChild == null)
            {
                return false;
            }

            return trieChild.WildcardSearch(s.Substring(1));
        }
    }
}
